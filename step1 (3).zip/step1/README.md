# final-step-1
Capstone final project
SkinMX - find your match
SkinMX is an app that can help you find your perfect skincare routine simplified. Find and document what products work for you
without being limited to a single brand. Eliminate the need to repurchase products that you can't necessarily remember if they actually worked.
Check your journal, see your progress. Welcome to SkinMX. 

